import "dotenv/config";

import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../app/generated/prisma/client";

const adapter = new PrismaPg({
  connectionString: process.env.DATABASE_URL!,
});

const prisma = new PrismaClient({
  adapter,
});

// ============================================================
// PERMISSIONS
// ============================================================

const permissions = [
  // ----------------------------------------------------------
  // Global user account
  // ----------------------------------------------------------

  {
    name: "user.read",
    description: "View global user accounts",
  },
  {
    name: "user.create",
    description: "Create global user accounts",
  },
  {
    name: "user.update",
    description: "Update global user accounts",
  },
  {
    name: "user.delete",
    description: "Delete global user accounts",
  },

  // ----------------------------------------------------------
  // Website members
  // ----------------------------------------------------------

  {
    name: "member.read",
    description: "View members assigned to a website",
  },
  {
    name: "member.invite",
    description: "Invite members to a website",
  },
  {
    name: "member.update",
    description: "Update member role or assignment within a website",
  },
  {
    name: "member.remove",
    description: "Remove a member from a website",
  },

  // ----------------------------------------------------------
  // Roles
  // ----------------------------------------------------------

  {
    name: "role.read",
    description: "View available roles",
  },
  {
    name: "role.create",
    description: "Create roles",
  },
  {
    name: "role.update",
    description: "Update roles",
  },
  {
    name: "role.delete",
    description: "Delete roles",
  },

  // ----------------------------------------------------------
  // Websites
  // ----------------------------------------------------------

  {
    name: "website.read",
    description: "View websites",
  },
  {
    name: "website.create",
    description: "Create websites",
  },
  {
    name: "website.update",
    description: "Update websites",
  },
  {
    name: "website.delete",
    description: "Delete websites",
  },

  // ----------------------------------------------------------
  // Videos
  // ----------------------------------------------------------

  {
    name: "video.read",
    description: "View videos",
  },
  {
    name: "video.create",
    description: "Create videos",
  },
  {
    name: "video.update",
    description: "Update videos",
  },
  {
    name: "video.delete",
    description: "Delete videos",
  },
  {
    name: "video.publish",
    description: "Publish videos",
  },

  // ----------------------------------------------------------
  // Categories
  // ----------------------------------------------------------

  {
    name: "category.read",
    description: "View categories",
  },
  {
    name: "category.create",
    description: "Create categories",
  },
  {
    name: "category.update",
    description: "Update categories",
  },
  {
    name: "category.delete",
    description: "Delete categories",
  },

  // ----------------------------------------------------------
  // Analytics
  // ----------------------------------------------------------

  {
    name: "view.read",
    description: "View video analytics",
  },

  // ----------------------------------------------------------
  // Audit
  // ----------------------------------------------------------

  {
    name: "audit.read",
    description: "View audit logs",
  },

  // ----------------------------------------------------------
  // API clients
  // ----------------------------------------------------------

  {
    name: "api_client.read",
    description: "View API clients",
  },
  {
    name: "api_client.create",
    description: "Create API clients",
  },
  {
    name: "api_client.revoke",
    description: "Revoke API clients",
  },
] as const;

// ============================================================
// ROLE DEFINITIONS
// ============================================================

const roleDefinitions = [
  {
    name: "SUPER_ADMIN",
    scope: "GLOBAL" as const,
    description: "Full global access to the Veyra system",
  },
  {
    name: "ADMIN",
    scope: "WEBSITE" as const,
    description: "Administrative access to an assigned website",
  },
  {
    name: "TEAM_LEAD",
    scope: "WEBSITE" as const,
    description: "Leads the operational team of an assigned website",
  },
  {
    name: "CONTENT_MANAGER",
    scope: "WEBSITE" as const,
    description: "Manages website content and publishing",
  },
  {
    name: "EDITOR",
    scope: "WEBSITE" as const,
    description: "Creates and edits website content",
  },
  {
    name: "DESIGNER",
    scope: "WEBSITE" as const,
    description: "Manages visual and media-related content",
  },
  {
    name: "ANALYST",
    scope: "WEBSITE" as const,
    description: "Views website analytics and performance data",
  },
  {
    name: "AUDITOR",
    scope: "WEBSITE" as const,
    description: "Read-only access to website audit information",
  },
] as const;

// ============================================================
// ROLE PERMISSIONS
// ============================================================

const rolePermissions = {
  // SUPER_ADMIN gets every permission automatically below.
  SUPER_ADMIN: permissions.map((permission) => permission.name),

  ADMIN: [
    "member.read",
    "member.invite",
    "member.update",
    "member.remove",

    "role.read",

    "website.read",
    "website.update",

    "video.read",
    "video.create",
    "video.update",
    "video.delete",
    "video.publish",

    "category.read",
    "category.create",
    "category.update",
    "category.delete",

    "view.read",

    "audit.read",

    "api_client.read",
    "api_client.create",
    "api_client.revoke",
  ],

  TEAM_LEAD: [
    "member.read",
    "member.invite",
    "member.update",

    "role.read",

    "website.read",

    "video.read",
    "video.create",
    "video.update",
    "video.delete",
    "video.publish",

    "category.read",
    "category.create",
    "category.update",
    "category.delete",

    "view.read",

    "audit.read",
  ],

  CONTENT_MANAGER: [
    "website.read",

    "video.read",
    "video.create",
    "video.update",
    "video.delete",
    "video.publish",

    "category.read",
    "category.create",
    "category.update",
    "category.delete",

    "view.read",
  ],

  EDITOR: [
    "website.read",

    "video.read",
    "video.create",
    "video.update",

    "category.read",
    "category.create",
    "category.update",
  ],

  DESIGNER: ["website.read", "video.read", "video.update", "category.read"],

  ANALYST: ["website.read", "view.read"],

  AUDITOR: ["website.read", "view.read", "audit.read"],
} as const;

// ============================================================
// HELPERS
// ============================================================

async function syncRolePermissions(
  roleId: string,
  permissionNames: readonly string[],
  permissionMap: Map<string, string>,
) {
  const permissionIds = permissionNames.map((permissionName) => {
    const permissionId = permissionMap.get(permissionName);

    if (!permissionId) {
      throw new Error(`Permission not found: ${permissionName}`);
    }

    return permissionId;
  });

  /*
   * Remove stale permissions from this system role.
   *
   * This is important because upsert alone only adds permissions.
   * If we remove a permission from rolePermissions above later,
   * the database must also remove that old assignment.
   */
  await prisma.rolePermission.deleteMany({
    where: {
      roleId,
      permissionId: {
        notIn: permissionIds,
      },
    },
  });

  for (const permissionId of permissionIds) {
    await prisma.rolePermission.upsert({
      where: {
        roleId_permissionId: {
          roleId,
          permissionId,
        },
      },
      update: {},
      create: {
        roleId,
        permissionId,
      },
    });
  }
}

// ============================================================
// MAIN
// ============================================================

async function main() {
  console.log("🌱 Starting database seed...");

  // ==========================================================
  // PERMISSIONS
  // ==========================================================

  const permissionMap = new Map<string, string>();

  for (const permissionData of permissions) {
    const permission = await prisma.permission.upsert({
      where: {
        name: permissionData.name,
      },
      update: {
        description: permissionData.description,
      },
      create: {
        name: permissionData.name,
        description: permissionData.description,
      },
    });

    permissionMap.set(permission.name, permission.id);
  }

  console.log(`✓ ${permissions.length} permissions ready`);

  // ==========================================================
  // ROLES
  // ==========================================================

  const roleMap = new Map<string, string>();

  for (const roleData of roleDefinitions) {
    const role = await prisma.role.upsert({
      where: {
        name: roleData.name,
      },
      update: {
        description: roleData.description,
        scope: roleData.scope,
      },
      create: {
        name: roleData.name,
        description: roleData.description,
        scope: roleData.scope,
      },
    });

    roleMap.set(role.name, role.id);
  }

  console.log(`✓ ${roleDefinitions.length} system roles ready`);

  // ==========================================================
  // ROLE PERMISSIONS
  // ==========================================================

  for (const roleData of roleDefinitions) {
    const roleId = roleMap.get(roleData.name);

    if (!roleId) {
      throw new Error(`Role not found: ${roleData.name}`);
    }

    await syncRolePermissions(
      roleId,
      rolePermissions[roleData.name],
      permissionMap,
    );

    console.log(`✓ ${roleData.name} permissions synchronized`);
  }

  // ==========================================================
  // RBAC INTEGRITY CHECKS
  // ==========================================================

  const superAdminRoleId = roleMap.get("SUPER_ADMIN");

  if (!superAdminRoleId) {
    throw new Error("SUPER_ADMIN role not found");
  }

  /*
   * SUPER_ADMIN must never exist more than once.
   *
   * The seed does not create or delete the SUPER_ADMIN user.
   * It only validates the invariant.
   */
  const superAdminCount = await prisma.userRole.count({
    where: {
      roleId: superAdminRoleId,
    },
  });

  if (superAdminCount > 1) {
    throw new Error(
      `Invalid RBAC state: ${superAdminCount} users have SUPER_ADMIN role. Only one is allowed.`,
    );
  }

  /*
   * UserRole is reserved for GLOBAL roles.
   *
   * Website roles must live in UserWebsiteRole.
   */
  const invalidGlobalAssignments = await prisma.userRole.count({
    where: {
      role: {
        scope: "WEBSITE",
      },
    },
  });

  if (invalidGlobalAssignments > 0) {
    throw new Error(
      `Invalid RBAC state: ${invalidGlobalAssignments} WEBSITE role assignments exist in user_role.`,
    );
  }

  /*
   * UserWebsiteRole may only reference WEBSITE roles.
   */
  const invalidWebsiteAssignments = await prisma.userWebsiteRole.count({
    where: {
      role: {
        scope: "GLOBAL",
      },
    },
  });

  if (invalidWebsiteAssignments > 0) {
    throw new Error(
      `Invalid RBAC state: ${invalidWebsiteAssignments} GLOBAL role assignments exist in user_website_role.`,
    );
  }

  console.log("✓ RBAC integrity checks passed");
  console.log("🌱 Database seed completed.");
}

// ============================================================
// EXECUTE
// ============================================================

main()
  .catch((error) => {
    console.error("❌ Seed failed:");
    console.error(error);

    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
