import { NextResponse } from "next/server";

import { requirePermission } from "@/lib/admin/auth-admin";
import { prisma } from "@/lib/prisma";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

const SYSTEM_ROLES = new Set([
  "SUPER_ADMIN",
  "ADMIN",
  "TEAM_LEAD",
  "CONTENT_MANAGER",
  "EDITOR",
  "DESIGNER",
  "ANALYST",
  "AUDITOR",
]);

function getRoleUserCount(globalUsers: number, websiteUsers: number): number {
  return globalUsers + websiteUsers;
}

export async function GET(request: Request, context: RouteContext) {
  const auth = await requirePermission(request, "role.read");

  if (!auth.success) {
    return NextResponse.json(
      {
        success: false,
        error: auth.error,
      },
      {
        status: auth.status,
      },
    );
  }

  const { id } = await context.params;

  const role = await prisma.role.findUnique({
    where: {
      id,
    },

    select: {
      id: true,
      name: true,
      description: true,
      scope: true,
      createdAt: true,
      updatedAt: true,

      _count: {
        select: {
          globalUsers: true,
          websiteUsers: true,
          rolePermissions: true,
        },
      },

      rolePermissions: {
        orderBy: {
          permission: {
            name: "asc",
          },
        },

        select: {
          permission: {
            select: {
              id: true,
              name: true,
              description: true,
            },
          },
        },
      },
    },
  });

  if (!role) {
    return NextResponse.json(
      {
        success: false,
        error: "Role not found",
      },
      {
        status: 404,
      },
    );
  }

  return NextResponse.json({
    success: true,

    data: {
      id: role.id,
      name: role.name,
      description: role.description,
      scope: role.scope,

      userCount: getRoleUserCount(
        role._count.globalUsers,
        role._count.websiteUsers,
      ),

      globalUserCount: role._count.globalUsers,
      websiteAssignmentCount: role._count.websiteUsers,

      permissionCount: role._count.rolePermissions,

      permissions: role.rolePermissions.map(
        (rolePermission) => rolePermission.permission,
      ),

      createdAt: role.createdAt,
      updatedAt: role.updatedAt,

      system: SYSTEM_ROLES.has(role.name),
    },
  });
}

export async function PUT(request: Request, context: RouteContext) {
  const auth = await requirePermission(request, "role.update");

  if (!auth.success) {
    return NextResponse.json(
      {
        success: false,
        error: auth.error,
      },
      {
        status: auth.status,
      },
    );
  }

  const { id } = await context.params;

  const existingRole = await prisma.role.findUnique({
    where: {
      id,
    },

    select: {
      id: true,
      name: true,
      scope: true,
    },
  });

  if (!existingRole) {
    return NextResponse.json(
      {
        success: false,
        error: "Role not found",
      },
      {
        status: 404,
      },
    );
  }

  let body: {
    name?: unknown;
    description?: unknown;
    permissions?: unknown;
  };

  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      {
        success: false,
        error: "Invalid JSON body",
      },
      {
        status: 400,
      },
    );
  }

  /*
   * System roles boleh diperbarui permission/description,
   * tetapi nama dan scope tidak boleh berubah.
   *
   * Seed tetap menjadi source of truth untuk system role.
   */
  const isSystemRole = SYSTEM_ROLES.has(existingRole.name);

  const requestedName =
    typeof body.name === "string"
      ? body.name.trim().toUpperCase()
      : existingRole.name;

  if (!requestedName) {
    return NextResponse.json(
      {
        success: false,
        error: "Role name is required",
      },
      {
        status: 400,
      },
    );
  }

  if (requestedName.length > 50) {
    return NextResponse.json(
      {
        success: false,
        error: "Role name must not exceed 50 characters",
      },
      {
        status: 400,
      },
    );
  }

  if (isSystemRole && requestedName !== existingRole.name) {
    return NextResponse.json(
      {
        success: false,
        error: "System role name cannot be changed",
      },
      {
        status: 403,
      },
    );
  }

  if (requestedName !== existingRole.name) {
    const duplicateRole = await prisma.role.findUnique({
      where: {
        name: requestedName,
      },

      select: {
        id: true,
      },
    });

    if (duplicateRole && duplicateRole.id !== id) {
      return NextResponse.json(
        {
          success: false,
          error: "Role already exists",
        },
        {
          status: 409,
        },
      );
    }
  }

  const description =
    body.description === null
      ? null
      : typeof body.description === "string"
        ? body.description.trim()
        : undefined;

  let permissionRecords:
    | {
        id: string;
        name: string;
      }[]
    | undefined;

  if (body.permissions !== undefined) {
    if (!Array.isArray(body.permissions)) {
      return NextResponse.json(
        {
          success: false,
          error: "Permissions must be an array",
        },
        {
          status: 400,
        },
      );
    }

    const permissionNames = [
      ...new Set(
        body.permissions
          .filter(
            (permission): permission is string =>
              typeof permission === "string",
          )
          .map((permission) => permission.trim())
          .filter(Boolean),
      ),
    ];

    permissionRecords =
      permissionNames.length > 0
        ? await prisma.permission.findMany({
            where: {
              name: {
                in: permissionNames,
              },
            },

            select: {
              id: true,
              name: true,
            },
          })
        : [];

    const foundPermissionNames = new Set(
      permissionRecords.map((permission) => permission.name),
    );

    const invalidPermissions = permissionNames.filter(
      (permission) => !foundPermissionNames.has(permission),
    );

    if (invalidPermissions.length > 0) {
      return NextResponse.json(
        {
          success: false,
          error: "One or more permissions do not exist",
          invalidPermissions,
        },
        {
          status: 400,
        },
      );
    }
  }

  const role = await prisma.$transaction(async (tx) => {
    await tx.role.update({
      where: {
        id,
      },

      data: {
        name: requestedName,

        ...(description !== undefined
          ? {
              description,
            }
          : {}),
      },
    });

    if (permissionRecords !== undefined) {
      await tx.rolePermission.deleteMany({
        where: {
          roleId: id,
        },
      });

      if (permissionRecords.length > 0) {
        await tx.rolePermission.createMany({
          data: permissionRecords.map((permission) => ({
            roleId: id,
            permissionId: permission.id,
          })),

          skipDuplicates: true,
        });
      }
    }

    return tx.role.findUnique({
      where: {
        id,
      },

      select: {
        id: true,
        name: true,
        description: true,
        scope: true,
        createdAt: true,
        updatedAt: true,

        _count: {
          select: {
            globalUsers: true,
            websiteUsers: true,
            rolePermissions: true,
          },
        },

        rolePermissions: {
          orderBy: {
            permission: {
              name: "asc",
            },
          },

          select: {
            permission: {
              select: {
                id: true,
                name: true,
                description: true,
              },
            },
          },
        },
      },
    });
  });

  if (!role) {
    return NextResponse.json(
      {
        success: false,
        error: "Failed to update role",
      },
      {
        status: 500,
      },
    );
  }

  return NextResponse.json({
    success: true,
    message: "Role updated successfully",

    data: {
      id: role.id,
      name: role.name,
      description: role.description,
      scope: role.scope,

      userCount: getRoleUserCount(
        role._count.globalUsers,
        role._count.websiteUsers,
      ),

      globalUserCount: role._count.globalUsers,

      websiteAssignmentCount: role._count.websiteUsers,

      permissionCount: role._count.rolePermissions,

      permissions: role.rolePermissions.map(
        (rolePermission) => rolePermission.permission,
      ),

      createdAt: role.createdAt,
      updatedAt: role.updatedAt,

      system: SYSTEM_ROLES.has(role.name),
    },
  });
}

export async function DELETE(request: Request, context: RouteContext) {
  const auth = await requirePermission(request, "role.delete");

  if (!auth.success) {
    return NextResponse.json(
      {
        success: false,
        error: auth.error,
      },
      {
        status: auth.status,
      },
    );
  }

  const { id } = await context.params;

  const role = await prisma.role.findUnique({
    where: {
      id,
    },

    select: {
      id: true,
      name: true,
      scope: true,

      _count: {
        select: {
          globalUsers: true,
          websiteUsers: true,
        },
      },
    },
  });

  if (!role) {
    return NextResponse.json(
      {
        success: false,
        error: "Role not found",
      },
      {
        status: 404,
      },
    );
  }

  /*
   * Semua built-in role dikelola oleh seed.
   * Jangan hapus dari API.
   */
  if (SYSTEM_ROLES.has(role.name)) {
    return NextResponse.json(
      {
        success: false,
        error: "System roles cannot be deleted",
      },
      {
        status: 403,
      },
    );
  }

  const assignmentCount = role._count.globalUsers + role._count.websiteUsers;

  if (assignmentCount > 0) {
    return NextResponse.json(
      {
        success: false,
        error: "Role cannot be deleted while it is assigned to users",
        assignmentCount,
      },
      {
        status: 409,
      },
    );
  }

  await prisma.role.delete({
    where: {
      id,
    },
  });

  return NextResponse.json({
    success: true,
    message: "Role deleted successfully",

    data: {
      id: role.id,
      name: role.name,
    },
  });
}
