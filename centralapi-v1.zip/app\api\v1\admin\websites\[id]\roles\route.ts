import { NextResponse } from "next/server";

import { requireWebsitePermission } from "@/lib/admin/auth-admin";
import { prisma } from "@/lib/prisma";

interface RouteContext {
  params: Promise<{
    id: string;
  }>;
}

const ROLE_PRIORITY: Record<string, number> = {
  ADMIN: 100,
  TEAM_LEAD: 80,
  CONTENT_MANAGER: 60,
  EDITOR: 50,
  DESIGNER: 50,
  ANALYST: 40,
  AUDITOR: 40,
};

function getRolePriority(roleName: string): number {
  return ROLE_PRIORITY[roleName] ?? 10;
}

export async function GET(request: Request, context: RouteContext) {
  const { id: websiteId } = await context.params;

  const auth = await requireWebsitePermission(
    request,
    websiteId,
    "member.read",
  );

  if (!auth.success) {
    return NextResponse.json(
      {
        success: false,
        error: auth.error,
      },
      {
        status: auth.status,
      },
    );
  }

  const roles = await prisma.role.findMany({
    where: {
      scope: "WEBSITE",
    },

    orderBy: {
      name: "asc",
    },

    select: {
      id: true,
      name: true,
      description: true,
      scope: true,
    },
  });

  const actorRoleName = auth.isSuperAdmin
    ? undefined
    : auth.websiteAssignment?.role.name;

  const allowedRoles = roles.filter((role) => {
    if (auth.isSuperAdmin) {
      return true;
    }

    if (!actorRoleName) {
      return false;
    }

    if (actorRoleName === "ADMIN") {
      return true;
    }

    return getRolePriority(role.name) < getRolePriority(actorRoleName);
  });

  return NextResponse.json({
    success: true,
    data: allowedRoles,
  });
}
