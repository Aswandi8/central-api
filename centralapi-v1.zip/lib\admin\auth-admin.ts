import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function authenticateAdminRequest(request: Request) {
  const session = await auth.api.getSession({
    headers: request.headers,
  });

  if (!session?.user) {
    return {
      success: false as const,
      status: 401,
      error: "Authentication required",
    };
  }

  const user = await prisma.user.findUnique({
    where: {
      id: session.user.id,
    },

    select: {
      id: true,
      name: true,
      email: true,
      emailVerified: true,
      image: true,
      status: true,
      banned: true,
      banReason: true,
      banExpires: true,
      createdAt: true,
      updatedAt: true,

      globalRoles: {
        select: {
          role: {
            select: {
              id: true,
              name: true,
              description: true,
              scope: true,

              rolePermissions: {
                select: {
                  permission: {
                    select: {
                      id: true,
                      name: true,
                      description: true,
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
  });

  if (!user) {
    return {
      success: false as const,
      status: 401,
      error: "User not found",
    };
  }

  if (user.status !== "ACTIVE") {
    return {
      success: false as const,
      status: 403,
      error: "User account is not active",
    };
  }

  if (user.banned) {
    return {
      success: false as const,
      status: 403,
      error: "User account is banned",
    };
  }

  const globalRoles = user.globalRoles.map((assignment) => assignment.role);

  const isSuperAdmin = globalRoles.some(
    (role) => role.name === "SUPER_ADMIN" && role.scope === "GLOBAL",
  );

  return {
    success: true as const,
    user,
    globalRoles,
    isSuperAdmin,
  };
}

export async function requirePermission(
  request: Request,
  permissionName: string,
) {
  const result = await authenticateAdminRequest(request);

  if (!result.success) {
    return result;
  }

  if (result.isSuperAdmin) {
    return result;
  }

  const hasPermission = result.globalRoles.some((role) =>
    role.rolePermissions.some(
      (rolePermission) => rolePermission.permission.name === permissionName,
    ),
  );

  if (!hasPermission) {
    return {
      success: false as const,
      status: 403,
      error: `Permission required: ${permissionName}`,
    };
  }

  return result;
}

export async function requireWebsitePermission(
  request: Request,
  websiteId: string,
  permissionName: string,
) {
  const result = await authenticateAdminRequest(request);

  if (!result.success) {
    return result;
  }

  if (result.isSuperAdmin) {
    return {
      ...result,
      websiteAssignment: null,
    };
  }

  /*
   * Query assignment secara langsung.
   *
   * Ini sengaja tidak mengambil seluruh websiteRoles milik user.
   * Kita hanya membutuhkan satu assignment untuk website target.
   * Lebih ringan dan tipe Prisma untuk role terjaga dengan benar.
   */
  const websiteAssignment = await prisma.userWebsiteRole.findUnique({
    where: {
      userId_websiteId: {
        userId: result.user.id,
        websiteId,
      },
    },

    select: {
      userId: true,
      websiteId: true,
      roleId: true,
      createdAt: true,
      updatedAt: true,

      website: {
        select: {
          id: true,
          name: true,
          slug: true,
          status: true,
        },
      },

      role: {
        select: {
          id: true,
          name: true,
          description: true,
          scope: true,

          rolePermissions: {
            select: {
              permission: {
                select: {
                  id: true,
                  name: true,
                  description: true,
                },
              },
            },
          },
        },
      },
    },
  });

  if (!websiteAssignment) {
    return {
      success: false as const,
      status: 403,
      error: "Website access denied",
    };
  }

  const hasPermission = websiteAssignment.role.rolePermissions.some(
    (rolePermission) => rolePermission.permission.name === permissionName,
  );

  if (!hasPermission) {
    return {
      success: false as const,
      status: 403,
      error: `Permission required: ${permissionName}`,
    };
  }

  return {
    ...result,
    websiteAssignment,
  };
}

export async function requireAdmin(request: Request) {
  const result = await authenticateAdminRequest(request);

  if (!result.success) {
    return result;
  }

  if (result.isSuperAdmin) {
    return result;
  }

  const adminAssignment = await prisma.userWebsiteRole.findFirst({
    where: {
      userId: result.user.id,

      role: {
        name: "ADMIN",
        scope: "WEBSITE",
      },
    },

    select: {
      userId: true,
    },
  });

  if (!adminAssignment) {
    return {
      success: false as const,
      status: 403,
      error: "Admin access required",
    };
  }

  return result;
}
