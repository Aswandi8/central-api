import { NextResponse } from "next/server";

import { requirePermission } from "@/lib/admin/auth-admin";
import { prisma } from "@/lib/prisma";

function getRoleUserCount(globalUsers: number, websiteUsers: number): number {
  return globalUsers + websiteUsers;
}

export async function GET(request: Request) {
  const auth = await requirePermission(request, "role.read");

  if (!auth.success) {
    return NextResponse.json(
      {
        success: false,
        error: auth.error,
      },
      {
        status: auth.status,
      },
    );
  }

  const roles = await prisma.role.findMany({
    orderBy: [
      {
        scope: "asc",
      },
      {
        name: "asc",
      },
    ],
    select: {
      id: true,
      name: true,
      description: true,
      scope: true,
      createdAt: true,
      updatedAt: true,

      _count: {
        select: {
          globalUsers: true,
          websiteUsers: true,
          rolePermissions: true,
        },
      },

      rolePermissions: {
        orderBy: {
          permission: {
            name: "asc",
          },
        },
        select: {
          permission: {
            select: {
              id: true,
              name: true,
              description: true,
            },
          },
        },
      },
    },
  });

  return NextResponse.json({
    success: true,

    data: roles.map((role) => ({
      id: role.id,
      name: role.name,
      description: role.description,
      scope: role.scope,

      userCount: getRoleUserCount(
        role._count.globalUsers,
        role._count.websiteUsers,
      ),

      globalUserCount: role._count.globalUsers,
      websiteAssignmentCount: role._count.websiteUsers,
      permissionCount: role._count.rolePermissions,

      permissions: role.rolePermissions.map(
        (rolePermission) => rolePermission.permission,
      ),

      createdAt: role.createdAt,
      updatedAt: role.updatedAt,
    })),
  });
}

export async function POST(request: Request) {
  const auth = await requirePermission(request, "role.create");

  if (!auth.success) {
    return NextResponse.json(
      {
        success: false,
        error: auth.error,
      },
      {
        status: auth.status,
      },
    );
  }

  let body: {
    name?: unknown;
    description?: unknown;
    permissions?: unknown;
  };

  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      {
        success: false,
        error: "Invalid JSON body",
      },
      {
        status: 400,
      },
    );
  }

  const name =
    typeof body.name === "string" ? body.name.trim().toUpperCase() : "";

  const description =
    body.description === null
      ? null
      : typeof body.description === "string"
        ? body.description.trim()
        : null;

  if (!name) {
    return NextResponse.json(
      {
        success: false,
        error: "Role name is required",
      },
      {
        status: 400,
      },
    );
  }

  if (name.length > 50) {
    return NextResponse.json(
      {
        success: false,
        error: "Role name must not exceed 50 characters",
      },
      {
        status: 400,
      },
    );
  }

  /*
   * SUPER_ADMIN adalah satu-satunya GLOBAL system role.
   * Global role baru tidak boleh dibuat melalui API.
   */
  if (name === "SUPER_ADMIN") {
    return NextResponse.json(
      {
        success: false,
        error: "SUPER_ADMIN is a protected system role",
      },
      {
        status: 403,
      },
    );
  }

  const existingRole = await prisma.role.findUnique({
    where: {
      name,
    },
    select: {
      id: true,
    },
  });

  if (existingRole) {
    return NextResponse.json(
      {
        success: false,
        error: "Role already exists",
      },
      {
        status: 409,
      },
    );
  }

  if (body.permissions !== undefined && !Array.isArray(body.permissions)) {
    return NextResponse.json(
      {
        success: false,
        error: "Permissions must be an array",
      },
      {
        status: 400,
      },
    );
  }

  const permissionNames = Array.isArray(body.permissions)
    ? [
        ...new Set(
          body.permissions
            .filter(
              (permission): permission is string =>
                typeof permission === "string",
            )
            .map((permission) => permission.trim())
            .filter(Boolean),
        ),
      ]
    : [];

  const permissionRecords =
    permissionNames.length > 0
      ? await prisma.permission.findMany({
          where: {
            name: {
              in: permissionNames,
            },
          },
          select: {
            id: true,
            name: true,
          },
        })
      : [];

  const foundPermissionNames = new Set(
    permissionRecords.map((permission) => permission.name),
  );

  const invalidPermissions = permissionNames.filter(
    (permission) => !foundPermissionNames.has(permission),
  );

  if (invalidPermissions.length > 0) {
    return NextResponse.json(
      {
        success: false,
        error: "One or more permissions do not exist",
        invalidPermissions,
      },
      {
        status: 400,
      },
    );
  }

  const role = await prisma.role.create({
    data: {
      name,
      description,

      /*
       * Semua custom role adalah website-scoped.
       */
      scope: "WEBSITE",

      rolePermissions: {
        create: permissionRecords.map((permission) => ({
          permissionId: permission.id,
        })),
      },
    },

    select: {
      id: true,
      name: true,
      description: true,
      scope: true,
      createdAt: true,
      updatedAt: true,

      _count: {
        select: {
          globalUsers: true,
          websiteUsers: true,
          rolePermissions: true,
        },
      },

      rolePermissions: {
        select: {
          permission: {
            select: {
              id: true,
              name: true,
              description: true,
            },
          },
        },
      },
    },
  });

  return NextResponse.json(
    {
      success: true,
      message: "Role created successfully",

      data: {
        id: role.id,
        name: role.name,
        description: role.description,
        scope: role.scope,

        userCount: getRoleUserCount(
          role._count.globalUsers,
          role._count.websiteUsers,
        ),

        globalUserCount: role._count.globalUsers,
        websiteAssignmentCount: role._count.websiteUsers,

        permissionCount: role._count.rolePermissions,

        permissions: role.rolePermissions.map(
          (rolePermission) => rolePermission.permission,
        ),

        createdAt: role.createdAt,
        updatedAt: role.updatedAt,
      },
    },
    {
      status: 201,
    },
  );
}
